
Readme file for MinGW compatible GLUT 3.7.6


This archive contains only the library file libglut32.a.  You will need to download the glut32.h header file and the glut32.dll file from Nate Robins' website (http://www.xmission.com/%7Enate/glut.html) to get those files.

libglut32.a was generated on January 5, 2003 using the latest release of GLUT (3.7.6) and the reimp tool by Chad M. Draper (chad@dratek.com).  This is to be used for MinGW compilers, such as Dev-C++.
